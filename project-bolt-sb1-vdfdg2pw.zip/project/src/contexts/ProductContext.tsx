import React, { createContext, useContext, useEffect, useState } from 'react'
import { googleSheetsService } from '../lib/googleSheets'
import toast from 'react-hot-toast'

interface ProductData {
  model: string
  display: string
  resolution: string
  os: string
  mainFeatures: string
  price: string
  imageUrl: string
  whatsappOrderLink: string
  id: string
}

interface ProductContextType {
  products: ProductData[]
  loading: boolean
  error: string | null
  refreshProducts: () => Promise<void>
  searchProducts: (query: string) => Promise<ProductData[]>
  getProductById: (id: string) => ProductData | null
}

const ProductContext = createContext<ProductContextType | undefined>(undefined)

export function useProducts() {
  const context = useContext(ProductContext)
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider')
  }
  return context
}

export function ProductProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<ProductData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchProducts = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await googleSheetsService.getProducts()
      setProducts(data)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load products'
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const refreshProducts = async () => {
    await fetchProducts()
    toast.success('Products refreshed!')
  }

  const searchProducts = async (query: string): Promise<ProductData[]> => {
    try {
      return await googleSheetsService.searchProducts(query)
    } catch (err) {
      toast.error('Search failed')
      return []
    }
  }

  const getProductById = (id: string): ProductData | null => {
    return products.find(product => product.id === id) || null
  }

  useEffect(() => {
    fetchProducts()
  }, [])

  const value = {
    products,
    loading,
    error,
    refreshProducts,
    searchProducts,
    getProductById
  }

  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  )
}