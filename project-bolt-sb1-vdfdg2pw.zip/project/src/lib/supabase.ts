import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          subscription_tier: 'free' | 'pro' | 'enterprise'
          credits_remaining: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          subscription_tier?: 'free' | 'pro' | 'enterprise'
          credits_remaining?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          subscription_tier?: 'free' | 'pro' | 'enterprise'
          credits_remaining?: number
          created_at?: string
          updated_at?: string
        }
      }
      searches: {
        Row: {
          id: string
          user_id: string
          product_name: string
          image_url: string | null
          search_results: any
          credits_used: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          product_name: string
          image_url?: string | null
          search_results?: any
          credits_used?: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          product_name?: string
          image_url?: string | null
          search_results?: any
          credits_used?: number
          created_at?: string
        }
      }
      saved_products: {
        Row: {
          id: string
          user_id: string
          product_name: string
          price: string
          store: string
          image_url: string | null
          product_url: string | null
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          product_name: string
          price: string
          store: string
          image_url?: string | null
          product_url?: string | null
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          product_name?: string
          price?: string
          store?: string
          image_url?: string | null
          product_url?: string | null
          notes?: string | null
          created_at?: string
        }
      }
    }
  }
}