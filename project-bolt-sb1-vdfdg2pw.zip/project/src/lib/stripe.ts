import { loadStripe } from '@stripe/stripe-js'

const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || 'pk_test_your_key'

export const stripe = loadStripe(stripePublishableKey)

export const SUBSCRIPTION_PLANS = {
  free: {
    name: 'Free',
    price: 0,
    credits: 10,
    features: [
      'Basic product identification',
      '10 searches per month',
      'Basic AI insights',
      'Email support'
    ]
  },
  pro: {
    name: 'Pro',
    price: 19,
    credits: 500,
    features: [
      'Advanced product identification',
      '500 searches per month',
      'Advanced AI insights',
      'Price tracking',
      'Bulk operations',
      'Priority support'
    ]
  },
  enterprise: {
    name: 'Enterprise',
    price: 99,
    credits: 5000,
    features: [
      'Unlimited product identification',
      '5000 searches per month',
      'Custom AI models',
      'API access',
      'White-label options',
      'Dedicated support'
    ]
  }
}