const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || 'your-gemini-api-key'

export class GeminiService {
  private apiKey: string

  constructor() {
    this.apiKey = GEMINI_API_KEY
  }

  async identifyProduct(base64Image: string): Promise<string> {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${this.apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              {
                text: "Identify the product in this image. Provide only the product name, brand, and model. Be concise and specific."
              },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: base64Image
                }
              }
            ]
          }]
        })
      }
    )

    if (!response.ok) {
      throw new Error('Failed to identify product')
    }

    const data = await response.json()
    return data.candidates[0].content.parts[0].text.trim()
  }

  async generateText(prompt: string): Promise<string> {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${this.apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        })
      }
    )

    if (!response.ok) {
      throw new Error('Failed to generate text')
    }

    const data = await response.json()
    return data.candidates[0].content.parts[0].text
  }

  async getSearchIdeas(productName: string): Promise<string> {
    return this.generateText(
      `Generate 5 alternative search terms for "${productName}". Format as a numbered list with brief explanations for each term.`
    )
  }

  async findAccessories(productName: string): Promise<string> {
    return this.generateText(
      `List 5 common accessories for "${productName}". Format as a numbered list with brief descriptions and typical price ranges.`
    )
  }

  async compareProducts(product1: string, product2: string): Promise<string> {
    return this.generateText(
      `Create a detailed comparison between "${product1}" and "${product2}". Include features, pros, cons, price comparison, and recommendations. Format as HTML with proper styling.`
    )
  }

  async analyzeDeal(productName: string, price: string): Promise<string> {
    return this.generateText(
      `Analyze if $${price} is a good deal for "${productName}". Provide typical price range, value assessment, and buying recommendation.`
    )
  }

  async summarizeReviews(productName: string): Promise<string> {
    return this.generateText(
      `Summarize typical pros and cons for "${productName}" based on user reviews. Format as HTML with separate lists for pros and cons.`
    )
  }
}

export const geminiService = new GeminiService()