interface ProductData {
  model: string
  display: string
  resolution: string
  os: string
  mainFeatures: string
  price: string
  imageUrl: string
  whatsappOrderLink: string
  id: string
}

interface SheetConfig {
  spreadsheetId: string
  range: string
  apiKey: string
}

export class GoogleSheetsService {
  private config: SheetConfig

  constructor(config: SheetConfig) {
    this.config = config
  }

  async getProducts(): Promise<ProductData[]> {
    try {
      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${this.config.spreadsheetId}/values/${this.config.range}?key=${this.config.apiKey}`
      )

      if (!response.ok) {
        throw new Error('Failed to fetch data from Google Sheets')
      }

      const data = await response.json()
      const rows = data.values || []

      // Skip header row
      const productRows = rows.slice(1)

      return productRows.map((row: string[], index: number) => ({
        id: `product-${index}`,
        model: row[0] || '',
        display: row[1] || '',
        resolution: row[2] || '',
        os: row[3] || '',
        mainFeatures: row[4] || '',
        price: row[5] || '',
        imageUrl: row[6] || 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=400',
        whatsappOrderLink: row[7] || ''
      }))
    } catch (error) {
      console.error('Error fetching products from Google Sheets:', error)
      throw error
    }
  }

  async getProductById(id: string): Promise<ProductData | null> {
    const products = await this.getProducts()
    return products.find(product => product.id === id) || null
  }

  async searchProducts(query: string): Promise<ProductData[]> {
    const products = await this.getProducts()
    const searchTerm = query.toLowerCase()
    
    return products.filter(product => 
      product.model.toLowerCase().includes(searchTerm) ||
      product.os.toLowerCase().includes(searchTerm) ||
      product.mainFeatures.toLowerCase().includes(searchTerm)
    )
  }
}

// Initialize with environment variables
export const googleSheetsService = new GoogleSheetsService({
  spreadsheetId: import.meta.env.VITE_GOOGLE_SHEETS_ID || '',
  range: import.meta.env.VITE_GOOGLE_SHEETS_RANGE || 'Sheet1!A:H',
  apiKey: import.meta.env.VITE_GOOGLE_SHEETS_API_KEY || ''
})