import React from 'react'
import { Link } from 'react-router-dom'
import { 
  EyeIcon, 
  DevicePhoneMobileIcon,
  ComputerDesktopIcon,
  CpuChipIcon
} from '@heroicons/react/24/outline'
import { formatPrice } from '../lib/utils'

interface ProductData {
  model: string
  display: string
  resolution: string
  os: string
  mainFeatures: string
  price: string
  imageUrl: string
  whatsappOrderLink: string
  id: string
}

interface ProductGridProps {
  products: ProductData[]
  loading?: boolean
}

export default function ProductGrid({ products, loading }: ProductGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {[...Array(8)].map((_, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 animate-pulse">
            <div className="h-48 bg-gray-200 rounded-t-lg"></div>
            <div className="p-4 space-y-3">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
              <div className="h-8 bg-gray-200 rounded"></div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <DevicePhoneMobileIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
        <p className="text-gray-500">Try adjusting your search or check back later for new products.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product) => (
        <div key={product.id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
          <div className="relative">
            <img
              src={product.imageUrl}
              alt={product.model}
              className="w-full h-48 object-cover rounded-t-lg"
              onError={(e) => {
                const target = e.target as HTMLImageElement
                target.src = 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=400'
              }}
            />
            <div className="absolute top-2 right-2">
              <span className="bg-primary-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                {product.os}
              </span>
            </div>
          </div>

          <div className="p-4">
            <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
              {product.model}
            </h3>

            <div className="space-y-2 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <ComputerDesktopIcon className="h-4 w-4 mr-2 text-gray-400" />
                <span>{product.display}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <CpuChipIcon className="h-4 w-4 mr-2 text-gray-400" />
                <span>{product.resolution}</span>
              </div>
            </div>

            <div className="mb-4">
              <p className="text-sm text-gray-600 line-clamp-2">
                {product.mainFeatures}
              </p>
            </div>

            <div className="flex items-center justify-between mb-4">
              <span className="text-xl font-bold text-primary-600">
                {formatPrice(product.price)}
              </span>
            </div>

            <div className="flex space-x-2">
              <Link
                to={`/product/${product.id}`}
                className="flex-1 flex items-center justify-center px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
              >
                <EyeIcon className="h-4 w-4 mr-1" />
                View Details
              </Link>
              
              {product.whatsappOrderLink && (
                <a
                  href={product.whatsappOrderLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center px-3 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-md transition-colors"
                >
                  Order Now
                </a>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}