import React, { useState, useEffect } from 'react'
import { MagnifyingGlassIcon, FunnelIcon } from '@heroicons/react/24/outline'

interface ProductData {
  model: string
  display: string
  resolution: string
  os: string
  mainFeatures: string
  price: string
  imageUrl: string
  whatsappOrderLink: string
  id: string
}

interface ProductFiltersProps {
  products: ProductData[]
  onFilter: (filteredProducts: ProductData[]) => void
  onSearch: (query: string) => void
}

export default function ProductFilters({ products, onFilter, onSearch }: ProductFiltersProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedOS, setSelectedOS] = useState('')
  const [priceRange, setPriceRange] = useState('')
  const [showFilters, setShowFilters] = useState(false)

  // Get unique OS options
  const osOptions = [...new Set(products.map(p => p.os).filter(Boolean))]
  
  // Price ranges
  const priceRanges = [
    { label: 'Under $500', min: 0, max: 500 },
    { label: '$500 - $1000', min: 500, max: 1000 },
    { label: '$1000 - $2000', min: 1000, max: 2000 },
    { label: 'Over $2000', min: 2000, max: Infinity }
  ]

  useEffect(() => {
    let filtered = products

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(product =>
        product.model.toLowerCase().includes(query) ||
        product.os.toLowerCase().includes(query) ||
        product.mainFeatures.toLowerCase().includes(query)
      )
    }

    // Apply OS filter
    if (selectedOS) {
      filtered = filtered.filter(product => product.os === selectedOS)
    }

    // Apply price filter
    if (priceRange) {
      const range = priceRanges.find(r => r.label === priceRange)
      if (range) {
        filtered = filtered.filter(product => {
          const price = parseFloat(product.price.replace(/[^0-9.]/g, ''))
          return price >= range.min && price <= range.max
        })
      }
    }

    onFilter(filtered)
  }, [searchQuery, selectedOS, priceRange, products])

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value
    setSearchQuery(query)
    onSearch(query)
  }

  const clearFilters = () => {
    setSearchQuery('')
    setSelectedOS('')
    setPriceRange('')
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
      {/* Search Bar */}
      <div className="relative mb-4">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Search products..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
        />
      </div>

      {/* Filter Toggle */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center text-sm font-medium text-gray-700 hover:text-gray-900"
        >
          <FunnelIcon className="h-4 w-4 mr-2" />
          Filters
        </button>
        
        {(selectedOS || priceRange) && (
          <button
            onClick={clearFilters}
            className="text-sm text-primary-600 hover:text-primary-700 font-medium"
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-gray-200">
          {/* OS Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Operating System
            </label>
            <select
              value={selectedOS}
              onChange={(e) => setSelectedOS(e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="">All OS</option>
              {osOptions.map(os => (
                <option key={os} value={os}>{os}</option>
              ))}
            </select>
          </div>

          {/* Price Range Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Price Range
            </label>
            <select
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="">All Prices</option>
              {priceRanges.map(range => (
                <option key={range.label} value={range.label}>{range.label}</option>
              ))}
            </select>
          </div>

          {/* Results Count */}
          <div className="flex items-end">
            <div className="text-sm text-gray-600">
              Showing {products.length} products
            </div>
          </div>
        </div>
      )}
    </div>
  )
}