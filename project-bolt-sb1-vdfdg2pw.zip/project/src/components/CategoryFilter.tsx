import React from 'react'
import { 
  DevicePhoneMobileIcon,
  ComputerDesktopIcon,
  DeviceTabletIcon,
  SpeakerWaveIcon,
  CameraIcon,
  TvIcon
} from '@heroicons/react/24/outline'

interface CategoryFilterProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
  categories: string[]
}

const categoryIcons: { [key: string]: React.ComponentType<any> } = {
  'iOS': DevicePhoneMobileIcon,
  'Android': DevicePhoneMobileIcon,
  'Windows': ComputerDesktopIcon,
  'macOS': ComputerDesktopIcon,
  'iPadOS': DeviceTabletIcon,
  'Audio': SpeakerWaveIcon,
  'Camera': CameraIcon,
  'TV': TvIcon,
}

export default function CategoryFilter({ selectedCategory, onCategoryChange, categories }: CategoryFilterProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <button
          onClick={() => onCategoryChange('')}
          className={`flex flex-col items-center p-4 rounded-lg border-2 transition-all ${
            selectedCategory === ''
              ? 'border-primary-500 bg-primary-50 text-primary-700'
              : 'border-gray-200 hover:border-gray-300 text-gray-600 hover:text-gray-900'
          }`}
        >
          <div className="w-8 h-8 mb-2 flex items-center justify-center">
            <div className="w-6 h-6 bg-current rounded opacity-20"></div>
          </div>
          <span className="text-sm font-medium">All</span>
        </button>

        {categories.map((category) => {
          const IconComponent = categoryIcons[category] || DevicePhoneMobileIcon
          
          return (
            <button
              key={category}
              onClick={() => onCategoryChange(category)}
              className={`flex flex-col items-center p-4 rounded-lg border-2 transition-all ${
                selectedCategory === category
                  ? 'border-primary-500 bg-primary-50 text-primary-700'
                  : 'border-gray-200 hover:border-gray-300 text-gray-600 hover:text-gray-900'
              }`}
            >
              <IconComponent className="w-8 h-8 mb-2" />
              <span className="text-sm font-medium">{category}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}