import React, { useState } from 'react'
import { 
  BookmarkIcon, 
  ChatBubbleLeftIcon, 
  ChartBarIcon,
  StarIcon 
} from '@heroicons/react/24/outline'
import { BookmarkIcon as BookmarkSolidIcon } from '@heroicons/react/24/solid'
import { formatPrice, truncateText } from '../lib/utils'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'
import toast from 'react-hot-toast'

interface ProductCardProps {
  product: {
    title: string
    price: string
    store: string
    imageUrl: string
    url?: string
  }
  onAskAI: () => void
  onAnalyzeDeal: () => void
  onSummarizeReviews: () => void
  onCompare?: () => void
  isSelected?: boolean
  onSelect?: () => void
}

export default function ProductCard({
  product,
  onAskAI,
  onAnalyzeDeal,
  onSummarizeReviews,
  onCompare,
  isSelected,
  onSelect
}: ProductCardProps) {
  const { user } = useAuth()
  const [isSaved, setIsSaved] = useState(false)
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    if (!user) return

    setSaving(true)
    try {
      const { error } = await supabase
        .from('saved_products')
        .insert({
          user_id: user.id,
          product_name: product.title,
          price: product.price,
          store: product.store,
          image_url: product.imageUrl,
          product_url: product.url
        })

      if (error) throw error

      setIsSaved(true)
      toast.success('Product saved!')
    } catch (error) {
      console.error('Error saving product:', error)
      toast.error('Failed to save product')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className={`bg-white rounded-lg shadow-sm border transition-all duration-200 hover:shadow-md ${
      isSelected ? 'ring-2 ring-primary-500 border-primary-200' : 'border-gray-200'
    }`}>
      <div className="relative">
        <img
          src={product.imageUrl}
          alt={product.title}
          className="w-full h-48 object-cover rounded-t-lg"
          onError={(e) => {
            const target = e.target as HTMLImageElement
            target.src = 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=400'
          }}
        />
        
        {onSelect && (
          <div className="absolute top-2 left-2">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={onSelect}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
            />
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={saving || isSaved}
          className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-sm hover:shadow-md transition-shadow"
        >
          {isSaved ? (
            <BookmarkSolidIcon className="h-5 w-5 text-primary-600" />
          ) : (
            <BookmarkIcon className="h-5 w-5 text-gray-600" />
          )}
        </button>
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
          {truncateText(product.title, 80)}
        </h3>
        
        <div className="flex items-center justify-between mb-3">
          <span className="text-lg font-bold text-green-600">
            {formatPrice(product.price)}
          </span>
          <span className="text-sm text-gray-500">{product.store}</span>
        </div>

        <div className="flex items-center mb-4">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <StarIcon
                key={i}
                className={`h-4 w-4 ${
                  i < 4 ? 'text-yellow-400 fill-current' : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="ml-2 text-sm text-gray-500">(4.2)</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onAskAI}
            className="flex items-center justify-center px-3 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors"
          >
            <ChatBubbleLeftIcon className="h-4 w-4 mr-1" />
            Ask AI
          </button>
          
          <button
            onClick={onSummarizeReviews}
            className="flex items-center justify-center px-3 py-2 text-xs font-medium text-white bg-green-600 hover:bg-green-700 rounded-md transition-colors"
          >
            <StarIcon className="h-4 w-4 mr-1" />
            Reviews
          </button>
          
          <button
            onClick={onAnalyzeDeal}
            className="flex items-center justify-center px-3 py-2 text-xs font-medium text-white bg-yellow-600 hover:bg-yellow-700 rounded-md transition-colors"
          >
            <ChartBarIcon className="h-4 w-4 mr-1" />
            Deal Analysis
          </button>
          
          {onCompare && (
            <button
              onClick={onCompare}
              className="flex items-center justify-center px-3 py-2 text-xs font-medium text-white bg-purple-600 hover:bg-purple-700 rounded-md transition-colors"
            >
              Compare
            </button>
          )}
        </div>
      </div>
    </div>
  )
}