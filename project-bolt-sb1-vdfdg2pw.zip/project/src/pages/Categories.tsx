import React, { useState, useEffect } from 'react'
import { useProducts } from '../contexts/ProductContext'
import ProductGrid from '../components/ProductGrid'
import CategoryFilter from '../components/CategoryFilter'
import ProductSort from '../components/ProductSort'
import LoadingSpinner from '../components/LoadingSpinner'

interface ProductData {
  model: string
  display: string
  resolution: string
  os: string
  mainFeatures: string
  price: string
  imageUrl: string
  whatsappOrderLink: string
  id: string
}

export default function Categories() {
  const { products, loading } = useProducts()
  const [filteredProducts, setFilteredProducts] = useState<ProductData[]>([])
  const [selectedCategory, setSelectedCategory] = useState('')
  const [sortBy, setSortBy] = useState('name-asc')

  // Get unique categories from products
  const categories = [...new Set(products.map(p => p.os).filter(Boolean))]

  useEffect(() => {
    let filtered = products

    // Apply category filter
    if (selectedCategory) {
      filtered = filtered.filter(product => product.os === selectedCategory)
    }

    // Apply sorting
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'name-asc':
          return a.model.localeCompare(b.model)
        case 'name-desc':
          return b.model.localeCompare(a.model)
        case 'price-asc':
          return parseFloat(a.price.replace(/[^0-9.]/g, '')) - parseFloat(b.price.replace(/[^0-9.]/g, ''))
        case 'price-desc':
          return parseFloat(b.price.replace(/[^0-9.]/g, '')) - parseFloat(a.price.replace(/[^0-9.]/g, ''))
        default:
          return 0
      }
    })

    setFilteredProducts(filtered)
  }, [products, selectedCategory, sortBy])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Product Categories</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Browse our products by category to find exactly what you're looking for
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Category Filter */}
        <CategoryFilter
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          categories={categories}
        />

        {/* Sort Controls */}
        <ProductSort
          sortBy={sortBy}
          onSortChange={setSortBy}
          totalProducts={filteredProducts.length}
        />

        {/* Products Grid */}
        <ProductGrid products={filteredProducts} loading={false} />

        {/* No Results */}
        {filteredProducts.length === 0 && !loading && (
          <div className="text-center py-16">
            <div className="text-gray-400 text-6xl mb-4">🔍</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-600 mb-6">
              {selectedCategory 
                ? `No products found in the ${selectedCategory} category.`
                : 'No products match your current filters.'
              }
            </p>
            <button
              onClick={() => {
                setSelectedCategory('')
                setSortBy('name-asc')
              }}
              className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  )
}