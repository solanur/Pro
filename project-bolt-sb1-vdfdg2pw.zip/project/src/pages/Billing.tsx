import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { SUBSCRIPTION_PLANS } from '../lib/stripe'
import { 
  CheckIcon, 
  CreditCardIcon, 
  StarIcon,
  TrendingUpIcon
} from '@heroicons/react/24/outline'
import { supabase } from '../lib/supabase'
import toast from 'react-hot-toast'

export default function Billing() {
  const { profile, refreshProfile } = useAuth()
  const [loading, setLoading] = useState<string | null>(null)

  const handleUpgrade = async (planName: string) => {
    setLoading(planName)
    
    try {
      // In a real app, you would integrate with Stripe here
      // For demo purposes, we'll simulate the upgrade
      
      const plan = SUBSCRIPTION_PLANS[planName as keyof typeof SUBSCRIPTION_PLANS]
      
      // Update user's subscription in database
      const { error } = await supabase
        .from('profiles')
        .update({
          subscription_tier: planName,
          credits_remaining: plan.credits
        })
        .eq('id', profile?.id)

      if (error) throw error

      await refreshProfile()
      toast.success(`Successfully upgraded to ${plan.name} plan!`)
    } catch (error) {
      console.error('Upgrade error:', error)
      toast.error('Failed to upgrade plan. Please try again.')
    } finally {
      setLoading(null)
    }
  }

  const currentPlan = profile?.subscription_tier || 'free'

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Billing & Subscription</h1>
        <p className="text-lg text-gray-600">
          Manage your subscription and billing information
        </p>
      </div>

      {/* Current Plan Status */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 capitalize">
              Current Plan: {currentPlan}
            </h3>
            <p className="text-gray-600 mt-1">
              {profile?.credits_remaining || 0} credits remaining
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <TrendingUpIcon className="h-8 w-8 text-primary-600" />
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-900">
                ${SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.price || 0}
              </div>
              <div className="text-sm text-gray-500">per month</div>
            </div>
          </div>
        </div>

        {/* Credits Progress Bar */}
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Credits Used</span>
            <span>
              {(SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 0) - (profile?.credits_remaining || 0)} / {SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 0}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary-600 h-2 rounded-full transition-all duration-300"
              style={{
                width: `${((SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 0) - (profile?.credits_remaining || 0)) / (SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 1) * 100}%`
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* Subscription Plans */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
          Choose Your Plan
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {Object.entries(SUBSCRIPTION_PLANS).map(([key, plan]) => {
            const isCurrentPlan = currentPlan === key
            const isPopular = key === 'pro'
            
            return (
              <div
                key={key}
                className={`bg-white rounded-lg shadow-sm border-2 p-8 relative ${
                  isPopular ? 'border-primary-500' : 'border-gray-200'
                } ${isCurrentPlan ? 'ring-2 ring-primary-200' : ''}`}
              >
                {isPopular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                      Most Popular
                    </span>
                  </div>
                )}
                
                {isCurrentPlan && (
                  <div className="absolute -top-3 right-4">
                    <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center">
                      <StarIcon className="h-3 w-3 mr-1" />
                      Current
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {plan.name}
                  </h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-gray-900">
                      ${plan.price}
                    </span>
                    <span className="text-gray-600">/month</span>
                  </div>
                  <p className="text-gray-600">
                    {plan.credits.toLocaleString()} searches per month
                  </p>
                </div>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckIcon className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button
                  onClick={() => handleUpgrade(key)}
                  disabled={isCurrentPlan || loading === key}
                  className={`block w-full text-center py-3 px-4 rounded-lg font-semibold transition-colors ${
                    isCurrentPlan
                      ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                      : isPopular
                      ? 'bg-primary-600 hover:bg-primary-700 text-white'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                  }`}
                >
                  {loading === key ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current mr-2"></div>
                      Processing...
                    </div>
                  ) : isCurrentPlan ? (
                    'Current Plan'
                  ) : (
                    `Upgrade to ${plan.name}`
                  )}
                </button>
              </div>
            )
          })}
        </div>
      </div>

      {/* Billing Information */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center mb-4">
          <CreditCardIcon className="h-6 w-6 text-gray-600 mr-3" />
          <h3 className="text-lg font-semibold text-gray-900">Billing Information</h3>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <div className="text-gray-900">{profile?.email}</div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Plan
              </label>
              <div className="text-gray-900 capitalize">{currentPlan}</div>
            </div>
          </div>
          
          <div className="pt-4 border-t border-gray-200">
            <p className="text-sm text-gray-600">
              * This is a demo application. In a production environment, you would integrate with Stripe or another payment processor for real billing functionality.
            </p>
          </div>
        </div>
      </div>

      {/* Usage Statistics */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Usage This Month</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary-600 mb-2">
              {(SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 0) - (profile?.credits_remaining || 0)}
            </div>
            <div className="text-sm text-gray-600">Searches Used</div>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {profile?.credits_remaining || 0}
            </div>
            <div className="text-sm text-gray-600">Credits Remaining</div>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">
              {Math.round(((SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 0) - (profile?.credits_remaining || 0)) / (SUBSCRIPTION_PLANS[currentPlan as keyof typeof SUBSCRIPTION_PLANS]?.credits || 1) * 100)}%
            </div>
            <div className="text-sm text-gray-600">Usage Rate</div>
          </div>
        </div>
      </div>
    </div>
  )
}