import React from 'react'
import { 
  ShieldCheckIcon,
  TruckIcon,
  CurrencyDollarIcon,
  HeartIcon,
  StarIcon,
  UsersIcon
} from '@heroicons/react/24/outline'

export default function About() {
  const siteName = import.meta.env.VITE_SITE_NAME || 'TechStore Pro'
  const siteDescription = import.meta.env.VITE_SITE_DESCRIPTION || 'Premium Electronics & Gadgets'

  const features = [
    {
      icon: ShieldCheckIcon,
      title: 'Quality Guarantee',
      description: 'All products come with manufacturer warranty and our quality assurance.'
    },
    {
      icon: TruckIcon,
      title: 'Fast Shipping',
      description: 'Quick and reliable delivery to your doorstep with tracking information.'
    },
    {
      icon: CurrencyDollarIcon,
      title: 'Best Prices',
      description: 'Competitive pricing with regular deals and discounts for our customers.'
    },
    {
      icon: HeartIcon,
      title: 'Customer Care',
      description: 'Dedicated support team ready to help with any questions or concerns.'
    }
  ]

  const stats = [
    { label: 'Happy Customers', value: '10,000+', icon: UsersIcon },
    { label: 'Products Sold', value: '50,000+', icon: StarIcon },
    { label: 'Years Experience', value: '5+', icon: ShieldCheckIcon },
    { label: 'Customer Rating', value: '4.9/5', icon: StarIcon }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About {siteName}
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto">
              {siteDescription} - Your trusted partner for cutting-edge technology and premium electronics
            </p>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-4">
                  <stat.icon className="w-8 h-8 text-primary-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Story Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  Founded with a passion for technology and innovation, {siteName} has been at the forefront 
                  of bringing the latest electronics and gadgets to tech enthusiasts worldwide.
                </p>
                <p>
                  We believe that everyone deserves access to premium technology at fair prices. That's why 
                  we carefully curate our product selection, working directly with manufacturers and trusted 
                  suppliers to ensure authenticity and quality.
                </p>
                <p>
                  Our team of tech experts constantly researches the market to bring you the most innovative 
                  products, from smartphones and laptops to smart home devices and accessories.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Our team"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We're committed to providing the best shopping experience with these key benefits
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-6">
                  <feature.icon className="w-8 h-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="py-16 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
              To democratize access to cutting-edge technology by providing authentic, high-quality 
              electronics at competitive prices, backed by exceptional customer service and support. 
              We strive to be your trusted technology partner, helping you stay connected and productive 
              in an ever-evolving digital world.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Explore Our Products?
          </h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Discover our carefully curated selection of premium electronics and find your next favorite gadget.
          </p>
          <a
            href="/products"
            className="inline-flex items-center bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors"
          >
            Browse Products
          </a>
        </div>
      </div>
    </div>
  )
}