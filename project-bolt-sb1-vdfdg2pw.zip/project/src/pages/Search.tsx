import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { geminiService } from '../lib/gemini'
import { supabase } from '../lib/supabase'
import { fileToBase64 } from '../lib/utils'
import ProductCard from '../components/ProductCard'
import Modal from '../components/Modal'
import { 
  CameraIcon, 
  SparklesIcon, 
  MagnifyingGlassIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline'
import toast from 'react-hot-toast'

interface SearchResult {
  title: string
  price: string
  store: string
  imageUrl: string
  url?: string
}

export default function Search() {
  const { user, profile, refreshProfile } = useAuth()
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string>('')
  const [identifiedProduct, setIdentifiedProduct] = useState<string>('')
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [selectedProducts, setSelectedProducts] = useState<number[]>([])
  const [loading, setLoading] = useState(false)
  const [searchLoading, setSearchLoading] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalTitle, setModalTitle] = useState('')
  const [modalContent, setModalContent] = useState('')
  const [questionModalOpen, setQuestionModalOpen] = useState(false)
  const [question, setQuestion] = useState('')
  const [currentProduct, setCurrentProduct] = useState<SearchResult | null>(null)

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setSelectedImage(file)
    const reader = new FileReader()
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)
  }

  const identifyProduct = async () => {
    if (!selectedImage || !user) return

    // Check credits
    if ((profile?.credits_remaining || 0) < 1) {
      toast.error('Insufficient credits. Please upgrade your plan.')
      return
    }

    setLoading(true)
    try {
      const base64Image = await fileToBase64(selectedImage)
      const productName = await geminiService.identifyProduct(base64Image)
      
      setIdentifiedProduct(productName)
      
      // Save search to database
      const { error } = await supabase
        .from('searches')
        .insert({
          user_id: user.id,
          product_name: productName,
          image_url: imagePreview,
          credits_used: 1
        })

      if (error) throw error

      // Update user credits
      await supabase
        .from('profiles')
        .update({ 
          credits_remaining: (profile?.credits_remaining || 0) - 1 
        })
        .eq('id', user.id)

      await refreshProfile()
      
      // Auto-search for the product
      await searchProducts(productName)
      
      toast.success('Product identified successfully!')
    } catch (error) {
      console.error('Error identifying product:', error)
      toast.error('Failed to identify product. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const searchProducts = async (query: string) => {
    setSearchLoading(true)
    try {
      // Mock search results since we don't have actual API keys
      const mockResults: SearchResult[] = [
        {
          title: `${query} - Premium Quality`,
          price: '29.99',
          store: 'Amazon',
          imageUrl: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          title: `${query} - Best Value`,
          price: '24.99',
          store: 'eBay',
          imageUrl: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          title: `${query} - Professional Grade`,
          price: '39.99',
          store: 'Walmart',
          imageUrl: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          title: `${query} - Economy Option`,
          price: '19.99',
          store: 'Target',
          imageUrl: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=400'
        }
      ]
      
      setSearchResults(mockResults)
    } catch (error) {
      console.error('Search error:', error)
      toast.error('Failed to search for products')
    } finally {
      setSearchLoading(false)
    }
  }

  const handleProductSelect = (index: number) => {
    if (selectedProducts.includes(index)) {
      setSelectedProducts(selectedProducts.filter(i => i !== index))
    } else if (selectedProducts.length < 2) {
      setSelectedProducts([...selectedProducts, index])
    } else {
      toast.error('You can only compare 2 products at a time')
    }
  }

  const compareProducts = async () => {
    if (selectedProducts.length !== 2) return

    const product1 = searchResults[selectedProducts[0]]
    const product2 = searchResults[selectedProducts[1]]

    try {
      const comparison = await geminiService.compareProducts(product1.title, product2.title)
      setModalTitle('Product Comparison')
      setModalContent(comparison)
      setModalOpen(true)
    } catch (error) {
      toast.error('Failed to compare products')
    }
  }

  const handleAskAI = (product: SearchResult) => {
    setCurrentProduct(product)
    setQuestionModalOpen(true)
  }

  const submitQuestion = async () => {
    if (!question.trim() || !currentProduct) return

    try {
      const answer = await geminiService.generateText(
        `About the product "${currentProduct.title}" (priced at $${currentProduct.price} from ${currentProduct.store}): ${question}`
      )
      setModalTitle('AI Answer')
      setModalContent(answer)
      setModalOpen(true)
      setQuestionModalOpen(false)
      setQuestion('')
    } catch (error) {
      toast.error('Failed to get AI answer')
    }
  }

  const handleAnalyzeDeal = async (product: SearchResult) => {
    try {
      const analysis = await geminiService.analyzeDeal(product.title, product.price)
      setModalTitle('Deal Analysis')
      setModalContent(analysis)
      setModalOpen(true)
    } catch (error) {
      toast.error('Failed to analyze deal')
    }
  }

  const handleSummarizeReviews = async (product: SearchResult) => {
    try {
      const summary = await geminiService.summarizeReviews(product.title)
      setModalTitle('Review Summary')
      setModalContent(summary)
      setModalOpen(true)
    } catch (error) {
      toast.error('Failed to summarize reviews')
    }
  }

  const getSearchIdeas = async () => {
    if (!identifiedProduct) return

    try {
      const ideas = await geminiService.getSearchIdeas(identifiedProduct)
      setModalTitle('Search Ideas')
      setModalContent(ideas)
      setModalOpen(true)
    } catch (error) {
      toast.error('Failed to get search ideas')
    }
  }

  const findAccessories = async () => {
    if (!identifiedProduct) return

    try {
      const accessories = await geminiService.findAccessories(identifiedProduct)
      setModalTitle('Recommended Accessories')
      setModalContent(accessories)
      setModalOpen(true)
    } catch (error) {
      toast.error('Failed to find accessories')
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">AI Product Search</h1>
        <p className="text-lg text-gray-600">
          Upload a product image to identify it and find the best deals online
        </p>
      </div>

      {/* Credits Warning */}
      {(profile?.credits_remaining || 0) < 5 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center">
            <ExclamationTriangleIcon className="h-5 w-5 text-yellow-400 mr-2" />
            <p className="text-yellow-800">
              You have {profile?.credits_remaining || 0} credits remaining. 
              <a href="/billing" className="font-medium underline ml-1">Upgrade your plan</a> for more searches.
            </p>
          </div>
        </div>
      )}

      {/* Image Upload Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div className="text-center">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
            id="image-upload"
          />
          
          {imagePreview ? (
            <div className="mb-6">
              <img
                src={imagePreview}
                alt="Product preview"
                className="max-w-full h-64 object-contain mx-auto rounded-lg border border-gray-200"
              />
            </div>
          ) : (
            <div className="mb-6">
              <CameraIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No image selected</p>
            </div>
          )}

          <div className="space-x-4">
            <label
              htmlFor="image-upload"
              className="inline-flex items-center bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold cursor-pointer transition-colors"
            >
              <CameraIcon className="h-5 w-5 mr-2" />
              Choose Image
            </label>
            
            {selectedImage && (
              <button
                onClick={identifyProduct}
                disabled={loading || (profile?.credits_remaining || 0) < 1}
                className="inline-flex items-center bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                ) : (
                  <SparklesIcon className="h-5 w-5 mr-2" />
                )}
                Identify Product
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Identified Product */}
      {identifiedProduct && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-green-800">Identified Product:</h3>
              <p className="text-green-700 text-xl mt-1">{identifiedProduct}</p>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={getSearchIdeas}
                className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                Get Search Ideas
              </button>
              <button
                onClick={findAccessories}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                Find Accessories
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search Loading */}
      {searchLoading && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Searching for products...</p>
        </div>
      )}

      {/* Compare Button */}
      {selectedProducts.length === 2 && (
        <div className="text-center">
          <button
            onClick={compareProducts}
            className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
          >
            Compare Selected Products
          </button>
        </div>
      )}

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Search Results</h2>
            <div className="flex items-center text-sm text-gray-600">
              <MagnifyingGlassIcon className="h-4 w-4 mr-1" />
              {searchResults.length} products found
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {searchResults.map((product, index) => (
              <ProductCard
                key={index}
                product={product}
                onAskAI={() => handleAskAI(product)}
                onAnalyzeDeal={() => handleAnalyzeDeal(product)}
                onSummarizeReviews={() => handleSummarizeReviews(product)}
                isSelected={selectedProducts.includes(index)}
                onSelect={() => handleProductSelect(index)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Modals */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={modalTitle}
        size="lg"
      >
        <div 
          className="prose max-w-none"
          dangerouslySetInnerHTML={{ __html: modalContent }}
        />
      </Modal>

      <Modal
        isOpen={questionModalOpen}
        onClose={() => setQuestionModalOpen(false)}
        title="Ask AI"
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Question:
            </label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              rows={3}
              placeholder="Ask anything about this product..."
            />
          </div>
          <div className="flex justify-end space-x-3">
            <button
              onClick={() => setQuestionModalOpen(false)}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={submitQuestion}
              disabled={!question.trim()}
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-medium transition-colors disabled:opacity-50"
            >
              Ask AI
            </button>
          </div>
        </div>
      </Modal>
    </div>
  )
}