import React, { useState, useEffect } from 'react'
import { useProducts } from '../contexts/ProductContext'
import ProductGrid from '../components/ProductGrid'
import ProductFilters from '../components/ProductFilters'
import { ArrowPathIcon } from '@heroicons/react/24/outline'

interface ProductData {
  model: string
  display: string
  resolution: string
  os: string
  mainFeatures: string
  price: string
  imageUrl: string
  whatsappOrderLink: string
  id: string
}

export default function ProductListing() {
  const { products, loading, error, refreshProducts } = useProducts()
  const [filteredProducts, setFilteredProducts] = useState<ProductData[]>([])
  const [searchResults, setSearchResults] = useState<ProductData[]>([])

  useEffect(() => {
    setFilteredProducts(products)
    setSearchResults(products)
  }, [products])

  const handleFilter = (filtered: ProductData[]) => {
    setFilteredProducts(filtered)
  }

  const handleSearch = async (query: string) => {
    if (!query.trim()) {
      setSearchResults(products)
      return
    }

    // Simple client-side search for now
    const results = products.filter(product =>
      product.model.toLowerCase().includes(query.toLowerCase()) ||
      product.os.toLowerCase().includes(query.toLowerCase()) ||
      product.mainFeatures.toLowerCase().includes(query.toLowerCase())
    )
    setSearchResults(results)
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-6xl mb-4">⚠️</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Failed to Load Products</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={refreshProducts}
            className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-600 to-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Premium Product Catalog</h1>
            <p className="text-xl text-primary-100 max-w-2xl mx-auto">
              Discover our curated collection of the latest electronics and cutting-edge technology
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="mb-8 flex items-center justify-between">
          <div className="text-sm text-gray-600">
            Showing {filteredProducts.length} of {searchResults.length} products
          </div>
          <button
            onClick={refreshProducts}
            disabled={loading}
            className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
          >
            <ArrowPathIcon className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        {/* Filters */}
        <ProductFilters
          products={searchResults}
          onFilter={handleFilter}
          onSearch={handleSearch}
        />

        {/* Product Grid */}
        <ProductGrid products={filteredProducts} loading={loading} />
      </div>
    </div>
  )
}