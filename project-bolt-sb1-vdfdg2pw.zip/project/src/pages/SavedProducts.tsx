import React, { useEffect, useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { 
  BookmarkIcon, 
  TrashIcon, 
  ExternalLinkIcon,
  PencilIcon
} from '@heroicons/react/24/outline'
import { formatPrice, formatDate } from '../lib/utils'
import Modal from '../components/Modal'
import toast from 'react-hot-toast'

interface SavedProduct {
  id: string
  product_name: string
  price: string
  store: string
  image_url: string | null
  product_url: string | null
  notes: string | null
  created_at: string
}

export default function SavedProducts() {
  const { user } = useAuth()
  const [products, setProducts] = useState<SavedProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [editingProduct, setEditingProduct] = useState<SavedProduct | null>(null)
  const [editNotes, setEditNotes] = useState('')

  useEffect(() => {
    if (user) {
      fetchSavedProducts()
    }
  }, [user])

  const fetchSavedProducts = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('saved_products')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setProducts(data || [])
    } catch (error) {
      console.error('Error fetching saved products:', error)
      toast.error('Failed to load saved products')
    } finally {
      setLoading(false)
    }
  }

  const deleteProduct = async (id: string) => {
    try {
      const { error } = await supabase
        .from('saved_products')
        .delete()
        .eq('id', id)

      if (error) throw error

      setProducts(products.filter(p => p.id !== id))
      toast.success('Product removed from saved list')
    } catch (error) {
      console.error('Error deleting product:', error)
      toast.error('Failed to remove product')
    }
  }

  const updateNotes = async () => {
    if (!editingProduct) return

    try {
      const { error } = await supabase
        .from('saved_products')
        .update({ notes: editNotes })
        .eq('id', editingProduct.id)

      if (error) throw error

      setProducts(products.map(p => 
        p.id === editingProduct.id 
          ? { ...p, notes: editNotes }
          : p
      ))
      
      setEditingProduct(null)
      setEditNotes('')
      toast.success('Notes updated successfully')
    } catch (error) {
      console.error('Error updating notes:', error)
      toast.error('Failed to update notes')
    }
  }

  const openEditModal = (product: SavedProduct) => {
    setEditingProduct(product)
    setEditNotes(product.notes || '')
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Saved Products</h1>
          <p className="text-gray-600 mt-2">
            {products.length} product{products.length !== 1 ? 's' : ''} saved
          </p>
        </div>
        <BookmarkIcon className="h-8 w-8 text-primary-600" />
      </div>

      {/* Products Grid */}
      {products.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <div className="relative">
                <img
                  src={product.image_url || 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=400'}
                  alt={product.product_name}
                  className="w-full h-48 object-cover"
                />
                <button
                  onClick={() => deleteProduct(product.id)}
                  className="absolute top-2 right-2 p-2 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors"
                >
                  <TrashIcon className="h-4 w-4" />
                </button>
              </div>
              
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                  {product.product_name}
                </h3>
                
                <div className="flex items-center justify-between mb-3">
                  <span className="text-lg font-bold text-green-600">
                    {formatPrice(product.price)}
                  </span>
                  <span className="text-sm text-gray-500">{product.store}</span>
                </div>

                <p className="text-xs text-gray-500 mb-3">
                  Saved on {formatDate(product.created_at)}
                </p>

                {product.notes && (
                  <div className="mb-3 p-2 bg-gray-50 rounded text-sm text-gray-700">
                    {product.notes}
                  </div>
                )}

                <div className="flex space-x-2">
                  <button
                    onClick={() => openEditModal(product)}
                    className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                  >
                    <PencilIcon className="h-4 w-4 mr-1" />
                    Edit Notes
                  </button>
                  
                  {product.product_url && (
                    <button
                      onClick={() => window.open(product.product_url!, '_blank')}
                      className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-md transition-colors"
                    >
                      <ExternalLinkIcon className="h-4 w-4 mr-1" />
                      View
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <BookmarkIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No saved products</h3>
          <p className="text-gray-600 mb-6">
            Products you save during searches will appear here.
          </p>
          <a
            href="/search"
            className="inline-flex items-center bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Start Searching
          </a>
        </div>
      )}

      {/* Edit Notes Modal */}
      <Modal
        isOpen={!!editingProduct}
        onClose={() => setEditingProduct(null)}
        title="Edit Notes"
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Product: {editingProduct?.product_name}
            </label>
            <textarea
              value={editNotes}
              onChange={(e) => setEditNotes(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              rows={4}
              placeholder="Add your notes about this product..."
            />
          </div>
          <div className="flex justify-end space-x-3">
            <button
              onClick={() => setEditingProduct(null)}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={updateNotes}
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Save Notes
            </button>
          </div>
        </div>
      </Modal>
    </div>
  )
}