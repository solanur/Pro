import React, { useEffect, useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { 
  CameraIcon, 
  MagnifyingGlassIcon, 
  BookmarkIcon,
  ChartBarIcon,
  TrendingUpIcon,
  ClockIcon
} from '@heroicons/react/24/outline'
import { Link } from 'react-router-dom'
import { formatDate } from '../lib/utils'

interface DashboardStats {
  totalSearches: number
  savedProducts: number
  creditsUsed: number
  recentSearches: any[]
}

export default function Dashboard() {
  const { user, profile } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalSearches: 0,
    savedProducts: 0,
    creditsUsed: 0,
    recentSearches: []
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      fetchDashboardData()
    }
  }, [user])

  const fetchDashboardData = async () => {
    if (!user) return

    try {
      // Fetch searches count
      const { count: searchesCount } = await supabase
        .from('searches')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)

      // Fetch saved products count
      const { count: savedCount } = await supabase
        .from('saved_products')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)

      // Fetch recent searches
      const { data: recentSearches } = await supabase
        .from('searches')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(5)

      // Calculate credits used
      const { data: creditsData } = await supabase
        .from('searches')
        .select('credits_used')
        .eq('user_id', user.id)

      const creditsUsed = creditsData?.reduce((sum, search) => sum + (search.credits_used || 1), 0) || 0

      setStats({
        totalSearches: searchesCount || 0,
        savedProducts: savedCount || 0,
        creditsUsed,
        recentSearches: recentSearches || []
      })
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const statCards = [
    {
      title: 'Total Searches',
      value: stats.totalSearches,
      icon: MagnifyingGlassIcon,
      color: 'bg-blue-500'
    },
    {
      title: 'Saved Products',
      value: stats.savedProducts,
      icon: BookmarkIcon,
      color: 'bg-green-500'
    },
    {
      title: 'Credits Used',
      value: stats.creditsUsed,
      icon: ChartBarIcon,
      color: 'bg-purple-500'
    },
    {
      title: 'Credits Remaining',
      value: profile?.credits_remaining || 0,
      icon: TrendingUpIcon,
      color: 'bg-orange-500'
    }
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary-600 to-indigo-600 rounded-lg p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">
          Welcome back, {profile?.full_name || user?.email}!
        </h1>
        <p className="text-primary-100 mb-6">
          Ready to discover amazing products with AI? Upload an image to get started.
        </p>
        <Link
          to="/search"
          className="inline-flex items-center bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
        >
          <CameraIcon className="h-5 w-5 mr-2" />
          Start New Search
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className={`p-3 rounded-lg ${stat.color}`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Searches */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Searches</h2>
          </div>
          <div className="p-6">
            {stats.recentSearches.length > 0 ? (
              <div className="space-y-4">
                {stats.recentSearches.map((search) => (
                  <div key={search.id} className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      {search.image_url ? (
                        <img
                          src={search.image_url}
                          alt={search.product_name}
                          className="h-12 w-12 rounded-lg object-cover"
                        />
                      ) : (
                        <div className="h-12 w-12 bg-gray-200 rounded-lg flex items-center justify-center">
                          <CameraIcon className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {search.product_name}
                      </p>
                      <div className="flex items-center text-xs text-gray-500">
                        <ClockIcon className="h-4 w-4 mr-1" />
                        {formatDate(search.created_at)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <MagnifyingGlassIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No searches yet</p>
                <Link
                  to="/search"
                  className="text-primary-600 hover:text-primary-700 font-medium"
                >
                  Start your first search
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <Link
                to="/search"
                className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <CameraIcon className="h-8 w-8 text-primary-600 mr-4" />
                <div>
                  <h3 className="font-medium text-gray-900">Upload & Search</h3>
                  <p className="text-sm text-gray-500">Find products by image</p>
                </div>
              </Link>
              
              <Link
                to="/saved"
                className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <BookmarkIcon className="h-8 w-8 text-green-600 mr-4" />
                <div>
                  <h3 className="font-medium text-gray-900">Saved Products</h3>
                  <p className="text-sm text-gray-500">View your saved items</p>
                </div>
              </Link>
              
              <Link
                to="/billing"
                className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <ChartBarIcon className="h-8 w-8 text-purple-600 mr-4" />
                <div>
                  <h3 className="font-medium text-gray-900">Upgrade Plan</h3>
                  <p className="text-sm text-gray-500">Get more credits</p>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Subscription Status */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 capitalize">
              {profile?.subscription_tier} Plan
            </h3>
            <p className="text-gray-600">
              {profile?.credits_remaining || 0} credits remaining
            </p>
          </div>
          <div className="flex space-x-4">
            <Link
              to="/billing"
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Manage Subscription
            </Link>
          </div>
        </div>
        
        {profile?.subscription_tier === 'free' && (
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-yellow-800">
              You're on the free plan. Upgrade to Pro for 500 searches per month and advanced features!
            </p>
          </div>
        )}
      </div>
    </div>
  )
}