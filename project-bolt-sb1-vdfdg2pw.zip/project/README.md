# Google Sheets Product Listing Website

A dynamic product catalog website that pulls data from Google Sheets and displays it as a beautiful, responsive product listing with customizable subdomain support.

## 🚀 Features

- **Google Sheets Integration** - Automatically sync products from your Google Sheets
- **Dynamic Product Catalog** - Real-time updates when you modify your sheet
- **Responsive Design** - Works perfectly on all devices
- **Product Search & Filters** - Find products by name, OS, price range
- **WhatsApp Integration** - Direct ordering via WhatsApp links
- **Custom Subdomain Ready** - Easy deployment with your own domain
- **SEO Optimized** - Fast loading and search engine friendly

## 📊 Google Sheets Setup

### 1. Create Your Product Sheet

Create a Google Sheet with the following columns (in this exact order):

| Column A | Column B | Column C | Column D | Column E | Column F | Column G | Column H |
|----------|----------|----------|----------|----------|----------|----------|----------|
| Model | Display | Resolution | OS | Main Features | Price | Image URL | WhatsApp Order Link |

### Example Data:
```
iPhone 15 Pro | 6.1" Super Retina XDR | 2556×1179 | iOS 17 | A17 Pro chip, 48MP camera, Titanium design | $999 | https://example.com/iphone15.jpg | https://wa.me/1234567890?text=I want to order iPhone 15 Pro
Samsung Galaxy S24 | 6.2" Dynamic AMOLED | 2340×1080 | Android 14 | Snapdragon 8 Gen 3, 50MP camera, AI features | $799 | https://example.com/galaxy-s24.jpg | https://wa.me/1234567890?text=I want to order Galaxy S24
```

### 2. Get Google Sheets API Key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable the Google Sheets API
4. Create credentials (API Key)
5. Copy your API key

### 3. Make Sheet Public

1. Open your Google Sheet
2. Click "Share" button
3. Change access to "Anyone with the link can view"
4. Copy the Sheet ID from the URL

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in your project root:

```env
# Google Sheets Configuration
VITE_GOOGLE_SHEETS_ID=1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms
VITE_GOOGLE_SHEETS_RANGE=Sheet1!A:H
VITE_GOOGLE_SHEETS_API_KEY=AIzaSyBnNAISIUQiQiQiQiQiQiQiQiQiQiQiQiQ

# Optional: Custom Branding
VITE_SITE_NAME=TechStore Pro
VITE_SITE_DESCRIPTION=Premium Electronics & Gadgets
VITE_CUSTOM_DOMAIN=shop.yourdomain.com
```

### Google Sheets ID

Extract the Sheet ID from your Google Sheets URL:
```
https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
                                    ↑ This is your Sheet ID ↑
```

## 🛠️ Installation & Setup

1. **Clone and Install**
```bash
npm install
```

2. **Configure Environment**
```bash
cp .env.example .env
# Edit .env with your Google Sheets details
```

3. **Start Development Server**
```bash
npm run dev
```

4. **Build for Production**
```bash
npm run build
```

## 📱 Product Data Format

### Required Fields:
- **Model**: Product name/model
- **Display**: Screen size and type
- **Resolution**: Display resolution
- **OS**: Operating system
- **Main Features**: Comma-separated features
- **Price**: Price with currency symbol
- **Image URL**: Direct link to product image
- **WhatsApp Order Link**: WhatsApp deep link for ordering

### WhatsApp Link Format:
```
https://wa.me/PHONENUMBER?text=MESSAGE
```

Example:
```
https://wa.me/1234567890?text=I want to order iPhone 15 Pro
```

## 🎨 Customization

### Branding
- Update site name and description in `.env`
- Modify colors in `tailwind.config.js`
- Replace logo and favicon in `public/` folder

### Styling
- Edit `src/index.css` for global styles
- Modify component styles in individual files
- Customize color scheme in Tailwind config

### Features
- Add new product fields by updating the Google Sheets service
- Implement additional filters in `ProductFilters.tsx`
- Add new pages by creating routes in `App.tsx`

## 🚀 Deployment

### Netlify (Recommended)
1. Connect your GitHub repository
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Add environment variables in Netlify dashboard
5. Deploy!

### Custom Domain
1. Add your domain in Netlify settings
2. Update DNS records to point to Netlify
3. SSL certificate will be automatically generated

### Vercel
1. Import project from GitHub
2. Set environment variables
3. Deploy with one click

## 📊 Analytics & SEO

### Google Analytics (Optional)
Add your GA tracking ID to `.env`:
```env
VITE_GA_TRACKING_ID=G-XXXXXXXXXX
```

### SEO Features
- Automatic meta tags generation
- Open Graph tags for social sharing
- Structured data for products
- Fast loading with image optimization

## 🔧 Advanced Features

### Auto-Refresh
Products automatically refresh when you update your Google Sheet (may take a few minutes due to caching).

### Search & Filters
- Real-time search across all product fields
- Filter by operating system
- Filter by price range
- Sort by various criteria

### Mobile Optimization
- Touch-friendly interface
- Responsive grid layout
- Fast loading on mobile networks
- WhatsApp integration for mobile ordering

## 📞 Support

For support and customization requests:
- Create an issue on GitHub
- Contact via WhatsApp integration
- Email support (if configured)

## 🔒 Security

- API keys are environment-based
- No sensitive data in client code
- HTTPS enforced in production
- Rate limiting on API calls

---

**Ready to launch your product catalog? Update your Google Sheet and watch your website automatically sync!** 🚀